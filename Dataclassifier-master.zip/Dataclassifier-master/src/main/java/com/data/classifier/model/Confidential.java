package com.data.classifier.model;

public class Confidential
{
    private String nameprefix;
    private String middleinitial;
    private String gender;
    private String fathername;
    private String mothername;
    private String mothermaidenname;
    private String weightinkgs;
    private String quarterofjoining;
    private String halfofjoining;
    private String monthofjoining;
    private String monthnameofjoining;
    private String dayofjoining;
    private String dowofjoining;
    private String shortdow;
    private String placename;
    private String county;
    private String city;
    private String state;
    private String zip;
    private String region;

    public String getNameprefix()
    {
        return nameprefix;
    }

    public void setNameprefix(String nameprefix)
    {
        this.nameprefix = nameprefix;
    }

    public String getMiddleinitial()
    {
        return middleinitial;
    }

    public void setMiddleinitial(String middleinitial)
    {
        this.middleinitial = middleinitial;
    }

    public String getGender()
    {
        return gender;
    }

    public void setGender(String gender)
    {
        this.gender = gender;
    }

    public String getFathername()
    {
        return fathername;
    }

    public void setFathername(String fathername)
    {
        this.fathername = fathername;
    }

    public String getMothername()
    {
        return mothername;
    }

    public void setMothername(String mothername)
    {
        this.mothername = mothername;
    }

    public String getMothermaidenname()
    {
        return mothermaidenname;
    }

    public void setMothermaidenname(String mothermaidenname)
    {
        this.mothermaidenname = mothermaidenname;
    }

    public String getWeightinkgs()
    {
        return weightinkgs;
    }

    public void setWeightinkgs(String weightinkgs)
    {
        this.weightinkgs = weightinkgs;
    }

    public String getQuarterofjoining()
    {
        return quarterofjoining;
    }

    public void setQuarterofjoining(String quarterofjoining)
    {
        this.quarterofjoining = quarterofjoining;
    }

    public String getHalfofjoining()
    {
        return halfofjoining;
    }

    public void setHalfofjoining(String halfofjoining)
    {
        this.halfofjoining = halfofjoining;
    }

    public String getMonthofjoining()
    {
        return monthofjoining;
    }

    public void setMonthofjoining(String monthofjoining)
    {
        this.monthofjoining = monthofjoining;
    }

    public String getMonthnameofjoining()
    {
        return monthnameofjoining;
    }

    public void setMonthnameofjoining(String monthnameofjoining)
    {
        this.monthnameofjoining = monthnameofjoining;
    }

    public String getDayofjoining()
    {
        return dayofjoining;
    }

    public void setDayofjoining(String dayofjoining)
    {
        this.dayofjoining = dayofjoining;
    }

    public String getDowofjoining()
    {
        return dowofjoining;
    }

    public void setDowofjoining(String dowofjoining)
    {
        this.dowofjoining = dowofjoining;
    }

    public String getShortdow()
    {
        return shortdow;
    }

    public void setShortdow(String shortdow)
    {
        this.shortdow = shortdow;
    }

    public String getPlacename()
    {
        return placename;
    }

    public void setPlacename(String placename)
    {
        this.placename = placename;
    }

    public String getCounty()
    {
        return county;
    }

    public void setCounty(String county)
    {
        this.county = county;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getZip()
    {
        return zip;
    }

    public void setZip(String zip)
    {
        this.zip = zip;
    }

    public String getRegion()
    {
        return region;
    }

    public void setRegion(String region)
    {
        this.region = region;
    }

}
